import React from 'react';
import './App.css';
import View from './View'


class App extends React.Component {


    render() {
        return <div>
            <div className="titleApp">veev</div>
            <View/>
        </div>;
    }
}

export default App
