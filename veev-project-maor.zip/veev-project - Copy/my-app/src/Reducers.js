export const fieldDisplay = (field = '1. Name', form) => {
    switch (form.type) {
        case "NAME":
            return '1. Name';
        case "EMAIL":
            return '2. Email';
        case "PHONE":
            return '3. Phone';
        default:
            return field;
    }
}

