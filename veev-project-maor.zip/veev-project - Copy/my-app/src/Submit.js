import React from 'react';

class Submit extends React.Component {
    render() {
        const {fields} = this.props;
        return <div>
            <div className="submit">
                <div className="nameTitle"><span className="marginRight">Name:</span><span>{fields.Name}</span></div>
                <div className="emailTitle"><span className="marginRight">Email:</span><span>{fields.Email}</span></div>
                <div className="phoneTitle"><span className="marginRight">Phone:</span><span>{fields.Phone}</span></div>
            </div>

        </div>;
    }
}

export default Submit
