import React from 'react';
import {changeToPhone, changeToEmail, changeToName} from './actions'
import {connect} from 'react-redux';
import Submit from './Submit'

class View extends React.Component {
    state = {
        fields: {
            Name: '',
            Email: '',
            Phone: ''
        },
        submit: false
    }
    handleChange = (e) => {
        const {fields} = this.state;
        const {fieldDisplay} = this.props;
        switch (fieldDisplay) {
            case '1. Name':
                fields['Name'] = e.target.value;
                break;
            case '2. Email':
                fields['Email'] = e.target.value;
                break;
            case '3. Phone':
                fields['Phone'] = e.target.value;
                break;
            default:
                return
        }
        this.setState({fields})
    }

    clearButton = () => {
        this.setState({
            fields: {
                Name: '',
                Email: '',
                Phone: ''
            },
            submit: false
        })
        let textbox = document.getElementById('myText');
        textbox.value = '';
    }

    render() {
        const {fieldDisplay, dispatch} = this.props
        const {fields, submit} = this.state;
        return <div className="container">
            <button type="button" className={`btn btn-secondary" ${fieldDisplay === '1. Name' ? 'orangeColor' : ''}`}
                    onClick={() => {
                        dispatch(changeToName('NAME'))
                    }}>1
            </button>
            <button type="button" className={`btn btn-secondary" ${fieldDisplay === '2. Email' ? 'orangeColor' : ''}`}
                    onClick={() => {
                        dispatch(changeToEmail('EMAIL'));
                    }}>2
            </button>
            <button type="button" className={`btn btn-secondary" ${fieldDisplay === '3. Phone' ? 'orangeColor' : ''}`}
                    onClick={() => {
                        dispatch(changeToPhone('PHONE'))
                    }}>3
            </button>
            <div className="textboxAndTitle">
                <div className="field">{fieldDisplay}</div>
                <div className="textBox"><input type="text" className="form-control" placeholder="type..." id="myText"
                                                aria-label="Username" aria-describedby="basic-addon1" onChange={(e) => {
                    this.handleChange(e)
                }} value={fields[fieldDisplay.split(' ')[1]]}/></div>
            </div>
            <div className="buttonsForm">
                <button type="button" className="btn btn-primary" onClick={() => {
                    this.setState({submit: true})
                }}>Save
                </button>
                <button type="button" className="btn btn-secondary" onClick={() => {
                    this.clearButton()
                }}>Clear
                </button>
            </div>
            <div className="submitComp">
                {submit ? <Submit fields={fields}/> : ''}
            </div>
        </div>;
    }
}

const mapStateToProps = (state) => {
    return {
        fieldDisplay: state.fieldDisplay
    }
}

export default connect(mapStateToProps)(View)