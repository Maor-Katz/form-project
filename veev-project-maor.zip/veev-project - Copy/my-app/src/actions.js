export const changeToName = (field) => {
    return {
        type: "NAME",
        payload: {
            field: field
        }
    }
}

export const changeToEmail = (field) => {
    return {
        type: "EMAIL",
        payload: {
            field: field
        }
    }
}

export const changeToPhone = (field) => {
    return {
        type: "PHONE",
        payload: {
            field: field
        }
    }
}


